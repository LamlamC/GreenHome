import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';

const Home = () => <div className="p-4 text-center">Bienvenue chez GreenHome 🌱</div>;
const Services = () => <div className="p-4">Nos Services</div>;
const Produits = () => <div className="p-4">Produits Écologiques</div>;
const Abonnements = () => <div className="p-4">Formules d'abonnement</div>;
const Offres = () => <div className="p-4">Offres promotionnelles</div>;
const Particuliers = () => <div className="p-4">Formulaire Particulier</div>;
const Professionnels = () => <div className="p-4">Formulaire Professionnel</div>;
const SecteurPublic = () => <div className="p-4">Formulaire Secteur Public</div>;
const Simulateur = () => <div className="p-4">Simulateur Économies</div>;
const Etudes = () => <div className="p-4">Études de cas</div>;
const FAQ = () => <div className="p-4">FAQ</div>;
const Contact = () => <div className="p-4">Contact & Devis</div>;
const Pourquoi = () => <div className="p-4">Pourquoi nous choisir ?</div>;
const Temoin = () => <div className="p-4">Témoignages</div>;
const Apropos = () => <div className="p-4">À propos</div>;

const App = () => {
  return (
    <div className="font-sans">
      <nav className="flex justify-around p-4 bg-green-600 text-white">
        <Link to="/">Accueil</Link>
        <Link to="/services">Services</Link>
        <Link to="/produits">Produits</Link>
        <Link to="/contact">Contact</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<Services />} />
        <Route path="/produits" element={<Produits />} />
        <Route path="/abonnements" element={<Abonnements />} />
        <Route path="/offres" element={<Offres />} />
        <Route path="/particuliers" element={<Particuliers />} />
        <Route path="/professionnels" element={<Professionnels />} />
        <Route path="/secteur-public" element={<SecteurPublic />} />
        <Route path="/simulateur" element={<Simulateur />} />
        <Route path="/etudes" element={<Etudes />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/pourquoi" element={<Pourquoi />} />
        <Route path="/temoignages" element={<Temoin />} />
        <Route path="/a-propos" element={<Apropos />} />
      </Routes>
    </div>
  );
};

export default App;